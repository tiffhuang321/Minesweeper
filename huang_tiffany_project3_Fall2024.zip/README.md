Name: Tiffany Huang
Section: 11819
UFL email: t.huang@ufl.edu
System: Windows 10
Compiler: g++
SFML version: 2.5.1
IDE: CLion
Other notes: game may take a couple seconds to load